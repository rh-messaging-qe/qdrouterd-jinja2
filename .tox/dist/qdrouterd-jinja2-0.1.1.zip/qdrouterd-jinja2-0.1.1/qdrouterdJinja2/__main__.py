#!/usr/bin/env python
# -*- coding: utf-8 -*-


from .qdrouterdJinja2 import main

if __name__ == '__main__':
    main()
