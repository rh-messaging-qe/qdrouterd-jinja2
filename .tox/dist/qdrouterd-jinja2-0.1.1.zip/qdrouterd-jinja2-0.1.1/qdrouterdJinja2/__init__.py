#!/usr/bin/env python
# -*- coding: utf-8 -*-

import sys

sys.path.insert(0, "/usr/lib/qpid-dispatch/python")
